export * from 'rxjs-compat/observable/forkJoin';
