export * from 'rxjs-compat/operators/first';
