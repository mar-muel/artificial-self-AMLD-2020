export * from 'rxjs-compat/operators/elementAt';
