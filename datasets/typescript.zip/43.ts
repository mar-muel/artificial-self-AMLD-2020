import { ISemVerDSL } from 'semver-dsl';
export declare const SemVerDSL: ISemVerDSL;
