/// <amd-module name="@angular/compiler/testing/src/resource_loader_mock.ngsummary" />
export {};
