export * from 'rxjs-compat/observable/DeferObservable';
