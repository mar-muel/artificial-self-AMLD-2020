export * from 'rxjs-compat/operators/timeInterval';
