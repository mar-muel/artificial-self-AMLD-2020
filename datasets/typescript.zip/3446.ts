export * from 'rxjs-compat/operators/last';
