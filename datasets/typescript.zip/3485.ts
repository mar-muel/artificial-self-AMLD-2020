export * from 'rxjs-compat/operators/reduce';
