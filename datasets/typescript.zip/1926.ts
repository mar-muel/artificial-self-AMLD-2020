/// <amd-module name="@angular/compiler/testing/src/schema_registry_mock.ngsummary" />
export {};
