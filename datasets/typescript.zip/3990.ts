export * from 'rxjs-compat/operator/bufferCount';
