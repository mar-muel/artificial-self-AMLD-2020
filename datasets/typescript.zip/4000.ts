export * from 'rxjs-compat/operator/buffer';
