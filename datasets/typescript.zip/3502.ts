export * from 'rxjs-compat/operators/toArray';
